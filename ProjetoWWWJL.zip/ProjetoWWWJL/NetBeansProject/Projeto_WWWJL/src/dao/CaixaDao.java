package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Usuario;
import mapeamento.Caixa;
import utilitario.Conectar;

public class CaixaDao {

    public void inserir(Caixa c) {
        Connection con = Conectar.getConectar();
        String sql = "INSERT INTO Caixa(codigo,periodoInicial,periodoFinal,horarioAbertura,horarioFechamento,metaEmpresa,valorTotalEntrada,valorTotalSaida,idUsuario_FK) VALUES(?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            
            stm.setInt(1, c.getCodigo());
            stm.setString(2, c.getPeriodoInicial());
            stm.setString(3, c.getPeriodoFinal());
            stm.setString(4, c.getHorarioAbertura());
            stm.setString(5, c.getHorarioFechamento());
            stm.setFloat(6, c.getMetaEmpresa());
            stm.setFloat(7, c.getValorTotalEntrada());
            stm.setFloat(8, c.getValorTotalSaida());
            stm.setInt(9, c.getUsuario().getIdUsuario());
            stm.executeUpdate();
            stm.close();
            con.close();
            JOptionPane.showMessageDialog(null, "Caixa " + c.getCodigo()+ " Cadastrado com Sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Cadastrar Caixa!", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }

    public void atualizar(Caixa c) {
        Connection con = Conectar.getConectar();
        String sql = "UPDATE Produto SET codigo= ?, periodoInicial= ?, periodoFinal= ?, horarioAbertura= ?, horarioFechamento= ?, metaEmpresa= ?, valorTotalEntrada= ?, valorTotalSaida= ?, idUsuario_FK= ? WHERE idCaixa= ?";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
          stm.setInt(1, c.getCodigo());
          stm.setString(2, c.getPeriodoInicial());
            stm.setString(3, c.getPeriodoFinal());
            stm.setString(4, c.getHorarioAbertura());
            stm.setString(5, c.getHorarioFechamento());
            stm.setFloat(6, c.getMetaEmpresa());
            stm.setFloat(7, c.getValorTotalEntrada());
            stm.setFloat(8, c.getValorTotalSaida());
            stm.setInt(9, c.getUsuario().getIdUsuario());
            stm.setInt(10, c.getIdCaixa());
            stm.executeUpdate();
            JOptionPane.showMessageDialog(null, c.getCodigo()+" Atualizado com Sucesso!");
            stm.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Atualizar Caixa", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }

    }

        public void deletar(Caixa c) {
        Connection con = Conectar.getConectar();
        String sql = "DELETE FROM Caixa WHERE idCaixa= ?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir o Produto " + c.getCodigo(), "Exclusão", JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION) {
            try (PreparedStatement stm = con.prepareStatement(sql)) {
                stm.setInt(1, c.getIdCaixa());
                stm.executeUpdate();
                JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
                stm.close();
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Erro ao deletar", null, JOptionPane.ERROR_MESSAGE);
                System.out.println(e.getMessage());
            }
        }
    }

    public List<Caixa> listarTodos(String data) {
        Connection con = Conectar.getConectar();
        List<Caixa> prList = new ArrayList();
        String sql = "SELECT * FROM Caixa, Usuario WHERE "
                + "Caixa.idUsuario_FK = Usuario.idUsuario and "
                + "periodoInicial Like ? ORDER BY nome";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setString(1, "%" + data + "%");
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Caixa c = new Caixa();
                c.setIdCaixa(resultados.getInt("Caixa.idCaixa"));
                c.setCodigo(resultados.getInt("Caixa.codigo"));
                c.setPeriodoInicial(resultados.getString("Caixa.periodoInicial"));
                c.setPeriodoFinal(resultados.getString("Caixa.periodoFinal"));
                c.setHorarioAbertura(resultados.getString("Caixa.horarioAbertura"));
                c.setHorarioFechamento(resultados.getString("Caixa.horarioFechamento"));
                c.setMetaEmpresa(resultados.getFloat("Caixa.metaEmpresa"));
                c.setValorTotalEntrada(resultados.getFloat("Caixa.valorTotalEntrada"));
                c.setValorTotalSaida(resultados.getFloat("Caixa.valorTotalSaida"));
                
                Usuario u = new Usuario();
                u.setIdUsuario(resultados.getInt("Usuario.idUsuario"));
                u.setNome(resultados.getString("Usuario.nome"));
                c.setUsuario(u);
                prList.add(c);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

    public List<Caixa> listarTodos() {
        Connection con = Conectar.getConectar();
        List<Caixa> prList = new ArrayList();
        String sql = "SELECT * FROM Caixa, Usuario WHERE "
                + "Caixa.idUsuario_FK = Usuario.idUsuario "
                + "ORDER BY nome";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
              Caixa c = new Caixa();
                c.setIdCaixa(resultados.getInt("Caixa.idCaixa"));
                c.setCodigo(resultados.getInt("Caixa.codigo"));
                c.setPeriodoInicial(resultados.getString("Caixa.periodoInicial"));
                c.setPeriodoFinal(resultados.getString("Caixa.periodoFinal"));
                c.setHorarioAbertura(resultados.getString("Caixa.horarioAbertura"));
                c.setHorarioFechamento(resultados.getString("Caixa.horarioFechamento"));
                c.setMetaEmpresa(resultados.getFloat("Caixa.metaEmpresa"));
                c.setValorTotalEntrada(resultados.getFloat("Caixa.valorTotalEntrada"));
                c.setValorTotalSaida(resultados.getFloat("Caixa.valorTotalSaida"));
                
                Usuario u = new Usuario();
                u.setIdUsuario(resultados.getInt("Usuario.idUsuario"));
                u.setNome(resultados.getString("Usuario.nome"));
                c.setUsuario(u);
                prList.add(c);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }
    
     public List<Caixa> listarTodos(int id) {
        Connection con = Conectar.getConectar();
        List<Caixa> prList = new ArrayList();
        String sql = "SELECT * FROM Caixa, Usuario WHERE idCaixa = ? and "
                + "Caixa.idUsuario_FK = Usuario.idUsuario";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, id);
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
               Caixa c = new Caixa();
                c.setIdCaixa(resultados.getInt("Caixa.idCaixa"));
                c.setCodigo(resultados.getInt("Caixa.codigo"));
                c.setPeriodoInicial(resultados.getString("Caixa.periodoInicial"));
                c.setPeriodoFinal(resultados.getString("Caixa.periodoFinal"));
                c.setHorarioAbertura(resultados.getString("Caixa.horarioAbertura"));
                c.setHorarioFechamento(resultados.getString("Caixa.horarioFechamento"));
                c.setMetaEmpresa(resultados.getFloat("Caixa.metaEmpresa"));
                c.setValorTotalEntrada(resultados.getFloat("Caixa.valorTotalEntrada"));
                c.setValorTotalSaida(resultados.getFloat("Caixa.valorTotalSaida"));
                
                Usuario u = new Usuario();
                u.setIdUsuario(resultados.getInt("Usuario.idUsuario"));
                u.setNome(resultados.getString("Usuario.nome"));
                c.setUsuario(u);
                prList.add(c);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

}
