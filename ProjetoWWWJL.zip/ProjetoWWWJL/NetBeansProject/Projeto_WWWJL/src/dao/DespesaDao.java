package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Fornecedor;
import mapeamento.Despesa;
import utilitario.Conectar;

public class DespesaDao {

    public void inserir(Despesa d) {
        Connection con = Conectar.getConectar();
        String sql = "INSERT INTO Despesa(tipoDeRenda,quantidade,valorUnitario,porcentagemDesconto,dataVenda,dataEntrega,valorFinal,idFornecedor_FK) VALUES(?,?,?,?,?,?,?,?)";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            
            stm.setString(1, d.getTipoDeRenda());
            stm.setInt(2, d.getQuantidade());
            stm.setFloat(3, d.getValorUnitario());
            stm.setFloat(4, d.getPorcentagem());
            stm.setString(5, d.getDataVenda());
            stm.setString(6, d.getDataEntrega());
            stm.setDouble(7, d.getValorFinal());
            stm.setInt(8, d.getFornecedor().getIdFornecedor());
            stm.executeUpdate();
            stm.close();
            con.close();
            JOptionPane.showMessageDialog(null, "Despesa " + d.getTipoDeRenda()+ " Cadastrado com Sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Cadastrar a despesa!", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }

    public void atualizar(Despesa d) {
        Connection con = Conectar.getConectar();
        String sql = "UPDATE Despesa SET tipoDeRenda= ?, quantidade= ?, valorUnitario= ?, porcentagemDesconto= ?, dataVenda= ?, dataEntrega= ?, valorFinal= ?, idFornecedor_FK= ? WHERE idDispesa= ?";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
          stm.setString(1, d.getTipoDeRenda());
            stm.setInt(2, d.getQuantidade());
            stm.setFloat(3, d.getValorUnitario());
            stm.setFloat(4, d.getPorcentagem());
            stm.setString(5, d.getDataVenda());
            stm.setString(6, d.getDataEntrega());
            stm.setDouble(7, d.getValorFinal());
            stm.setInt(8, d.getFornecedor().getIdFornecedor());
            stm.setInt(9, d.getIdDispesa());
            stm.executeUpdate();
            JOptionPane.showMessageDialog(null, d.getTipoDeRenda()+" Atualizado com Sucesso!");
            stm.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Atualizar Produto", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }

    }

    public void deletar(Despesa d) {
        Connection con = Conectar.getConectar();
        String sql = "DELETE FROM Despesa WHERE idDispesa= ?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir a Despesa " + d.getTipoDeRenda(), "Exclusão", JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION) {
            try (PreparedStatement stm = con.prepareStatement(sql)) {
                stm.setInt(1, d.getIdDispesa());
                stm.executeUpdate();
                JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
                stm.close();
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Erro ao deletar", null, JOptionPane.ERROR_MESSAGE);
                System.out.println(e.getMessage());
            }
        }
    }

    public List<Despesa> listarTodos(String nome) {
        Connection con = Conectar.getConectar();
        List<Despesa> prList = new ArrayList();
        String sql = "SELECT * FROM Despesa, Fornecedor WHERE "
                + "Despesa.idFornecedor_FK = Fornecedor.idFornecedor and "
                + "tipoDeRenda Like ? ORDER BY tipoDeRenda";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setString(1, "%" + nome + "%");
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Despesa d = new Despesa();
                d.setIdDispesa(resultados.getInt("Despesa.idDispesa"));
                d.setTipoDeRenda(resultados.getString("Despesa.tipoDeRenda"));
                d.setQuantidade(resultados.getInt("Despesa.quantidade"));
                d.setValorUnitario(resultados.getFloat("Despesa.valorUnitario"));
                d.setPorcentagem(resultados.getFloat("Despesa.porcentagemDesconto"));
                d.setDataVenda(resultados.getString("Despesa.dataVenda"));
                d.setDataEntrega(resultados.getString("Despesa.dataEntrega"));
                d.setValorFinal(resultados.getDouble("Despesa.valorFinal"));
                
                Fornecedor f = new Fornecedor();
                f.setIdFornecedor(resultados.getInt("Fornecedor.idFornecedor"));
                f.setNomeFantasia(resultados.getString("Fornecedor.nomeFantasia"));
                d.setFornecedor(f);
                prList.add(d);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

    public List<Despesa> listarTodos() {
        Connection con = Conectar.getConectar();
        List<Despesa> prList = new ArrayList();
        String sql = "SELECT * FROM Despesa, Fornecedor WHERE "
                + "Despesa.idFornecedor_FK = Fornecedor.idFornecedor "
                + "ORDER BY tipoDeRenda";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
              Despesa d = new Despesa();
                d.setIdDispesa(resultados.getInt("Despesa.idDispesa"));
                d.setTipoDeRenda(resultados.getString("Despesa.tipoDeRenda"));
                d.setQuantidade(resultados.getInt("Despesa.quantidade"));
                d.setValorUnitario(resultados.getFloat("Despesa.valorUnitario"));
                d.setPorcentagem(resultados.getFloat("Despesa.porcentagemDesconto"));
                d.setDataVenda(resultados.getString("Despesa.dataVenda"));
                d.setDataEntrega(resultados.getString("Despesa.dataEntrega"));
                d.setValorFinal(resultados.getDouble("Despesa.valorFinal"));
                
                Fornecedor f = new Fornecedor();
                f.setIdFornecedor(resultados.getInt("Fornecedor.idFornecedor"));
                f.setNomeFantasia(resultados.getString("Fornecedor.nomeFantasia"));
                d.setFornecedor(f);
                prList.add(d);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }
    
     public List<Despesa> listarTodos(int id) {
        Connection con = Conectar.getConectar();
        List<Despesa> prList = new ArrayList();
        String sql = "SELECT * FROM Despesa, Fornecedor WHERE idDispesa = ? and "
                + "Despesa.idFornecedor_FK = Fornecedor.idFornecedor";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, id);
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Despesa d = new Despesa();
                d.setIdDispesa(resultados.getInt("Despesa.idDispesa"));
                d.setTipoDeRenda(resultados.getString("Despesa.tipoDeRenda"));
                d.setQuantidade(resultados.getInt("Despesa.quantidade"));
                d.setValorUnitario(resultados.getFloat("Despesa.valorUnitario"));
                d.setPorcentagem(resultados.getFloat("Despesa.porcentagemDesconto"));
                d.setDataVenda(resultados.getString("Despesa.dataVenda"));
                d.setDataEntrega(resultados.getString("Despesa.dataEntrega"));
                d.setValorFinal(resultados.getDouble("Despesa.valorFinal"));
                
                Fornecedor f = new Fornecedor();
                f.setIdFornecedor(resultados.getInt("Fornecedor.idFornecedor"));
                f.setNomeFantasia(resultados.getString("Fornecedor.nomeFantasia"));d.setFornecedor(f);
                prList.add(d);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

}
