
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Fornecedor;
import mapeamento.Produto;
import utilitario.Conectar;

public class ProdutoDao {

    public void inserir(Produto p) {
        Connection con = Conectar.getConectar();
        String sql = "INSERT INTO Produto(codigo,nome,tipo,unidade,preco,dataEntrega,marca,cor,modelo,tamanho,avaliacao,idFornecedor_FK) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            
            stm.setInt(1, p.getCodigo());
            stm.setString(2, p.getNome());
            stm.setString(3, p.getTipo());
            stm.setInt(4, p.getUnidade());
            stm.setFloat(5, p.getPreco());
            stm.setString(6, p.getDataEntrega());
            stm.setString(7, p.getMarca());
            stm.setString(8, p.getCr());
            stm.setString(9, p.getModelo());
            stm.setString(10, p.getTamanho());
            stm.setString(11, p.getAvaliacao());
            stm.setInt(12, p.getFornecedor().getIdFornecedor());
            stm.executeUpdate();
            stm.close();
            con.close();
            JOptionPane.showMessageDialog(null, "Produto " + p.getNome()+ " Cadastrado com Sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Cadastrar o Produto!", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }

    public void atualizar(Produto p) {
        Connection con = Conectar.getConectar();
        String sql = "UPDATE Produto SET codigo= ?, nome= ?, tipo= ?, unidade= ?, preco= ?, dataEntrega= ?, marca= ?, cor= ?, modelo= ?, tamanho= ?, avaliacao= ?, idFornecedor_FK= ? WHERE idProduto= ?";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
          stm.setInt(1, p.getCodigo());
            stm.setString(2, p.getNome());
            stm.setString(3, p.getTipo());
            stm.setInt(4, p.getUnidade());
            stm.setFloat(5, p.getPreco());
            stm.setString(6, p.getDataEntrega());
            stm.setString(7, p.getMarca());
            stm.setString(8, p.getCr());
            stm.setString(9, p.getModelo());
            stm.setString(10, p.getTamanho());
            stm.setString(11, p.getAvaliacao());
            stm.setInt(12, p.getFornecedor().getIdFornecedor());
            stm.setInt(13, p.getIdProduto());
            stm.executeUpdate();
            JOptionPane.showMessageDialog(null, p.getNome()+" Atualizado com Sucesso!");
            stm.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Atualizar Produto", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }

    }

    public void deletar(Produto p) {
        Connection con = Conectar.getConectar();
        String sql = "DELETE FROM Produto WHERE idProduto= ?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir o Produto " + p.getNome(), "Exclusão", JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION) {
            try (PreparedStatement stm = con.prepareStatement(sql)) {
                stm.setInt(1, p.getIdProduto());
                stm.executeUpdate();
                JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
                stm.close();
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Erro ao deletar", null, JOptionPane.ERROR_MESSAGE);
                System.out.println(e.getMessage());
            }
        }
    }

    public List<Produto> listarTodos(String nome) {
        Connection con = Conectar.getConectar();
        List<Produto> prList = new ArrayList();
        String sql = "SELECT * FROM Produto, Fornecedor WHERE "
                + "Produto.idFornecedor_FK = Fornecedor.idFornecedor and "
                + "nome Like ? ORDER BY Produto.nome";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setString(1, "%" + nome + "%");
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Produto p = new Produto();
                p.setIdProduto(resultados.getInt("Produto.idProduto"));
                p.setCodigo(resultados.getInt("Produto.codigo"));
                p.setNome(resultados.getString("Produto.nome"));
                p.setTipo(resultados.getString("Produto.tipo"));
                p.setUnidade(resultados.getInt("Produto.unidade"));
                p.setPreco(resultados.getFloat("Produto.preco"));
                p.setDataEntrega(resultados.getString("Produto.dataEntrega"));
                p.setMarca(resultados.getString("Produto.marca"));
                p.setCr(resultados.getString("Produto.cor"));
                p.setModelo(resultados.getString("Produto.modelo"));
                p.setTamanho(resultados.getString("Produto.tamanho"));
                p.setAvaliacao(resultados.getString("Produto.avaliacao"));
                
                Fornecedor f = new Fornecedor();
                f.setIdFornecedor(resultados.getInt("Fornecedor.idFornecedor"));
                f.setNomeFantasia(resultados.getString("Fornecedor.nomeFantasia"));
                p.setFornecedor(f);
                prList.add(p);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

    public List<Produto> listarTodos() {
        Connection con = Conectar.getConectar();
        List<Produto> prList = new ArrayList();
        String sql = "SELECT * FROM Produto, Fornecedor WHERE "
                + "Produto.idFornecedor_FK = Fornecedor.idFornecedor "
                + "ORDER BY Produto.nome";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
              Produto p = new Produto();
                p.setIdProduto(resultados.getInt("Produto.idProduto"));
                p.setCodigo(resultados.getInt("Produto.codigo"));
                p.setNome(resultados.getString("Produto.nome"));
                p.setTipo(resultados.getString("Produto.tipo"));
                p.setUnidade(resultados.getInt("Produto.unidade"));
                p.setPreco(resultados.getFloat("Produto.preco"));
                p.setDataEntrega(resultados.getString("Produto.dataEntrega"));
                p.setMarca(resultados.getString("Produto.marca"));
                p.setCr(resultados.getString("Produto.cor"));
                p.setModelo(resultados.getString("Produto.modelo"));
                p.setTamanho(resultados.getString("Produto.tamanho"));
                p.setAvaliacao(resultados.getString("Produto.avaliacao"));
                
                Fornecedor f = new Fornecedor();
                f.setIdFornecedor(resultados.getInt("Fornecedor.idFornecedor"));
                f.setNomeFantasia(resultados.getString("Fornecedor.nomeFantasia"));
                p.setFornecedor(f);
                prList.add(p);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }
    
     public List<Produto> listarTodos(int id) {
        Connection con = Conectar.getConectar();
        List<Produto> prList = new ArrayList();
        String sql = "SELECT * FROM Produto, Fornecedor WHERE idProduto = ? and "
                + "Produto.idFornecedor_FK = Fornecedor.idFornecedor";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, id);
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
               Produto p = new Produto();
                p.setIdProduto(resultados.getInt("Produto.idProduto"));
                p.setCodigo(resultados.getInt("Produto.codigo"));
                p.setNome(resultados.getString("Produto.nome"));
                p.setTipo(resultados.getString("Produto.tipo"));
                p.setUnidade(resultados.getInt("Produto.unidade"));
                p.setPreco(resultados.getFloat("Produto.preco"));
                p.setDataEntrega(resultados.getString("Produto.dataEntrega"));
                p.setMarca(resultados.getString("Produto.marca"));
                p.setCr(resultados.getString("Produto.cor"));
                p.setModelo(resultados.getString("Produto.modelo"));
                p.setTamanho(resultados.getString("Produto.tamanho"));
                p.setAvaliacao(resultados.getString("Produto.avaliacao"));
                
                Fornecedor f = new Fornecedor();
                f.setIdFornecedor(resultados.getInt("Fornecedor.idFornecedor"));
                f.setNomeFantasia(resultados.getString("Fornecedor.nomeFantasia"));
                p.setFornecedor(f);
                prList.add(p);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

}
