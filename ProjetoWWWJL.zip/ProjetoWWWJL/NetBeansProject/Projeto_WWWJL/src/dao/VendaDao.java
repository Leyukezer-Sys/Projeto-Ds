package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Caixa;
import mapeamento.Cliente;
import mapeamento.Venda;
import utilitario.Conectar;

public class VendaDao {

    public void inserir(Venda v) {
        Connection con = Conectar.getConectar();
        String sql = "INSERT INTO Venda(valorTotalComDesconto,desconto,idCaixa_FK,idCliente_FK,codigo) VALUES(?,?,?,?,?)";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setFloat(1, v.getValorTotalComDesconto());
            stm.setFloat(2, v.getDesconto());
            stm.setInt(3, v.getCaixa().getIdCaixa());
            stm.setInt(4, v.getCliente().getIdCliente());
            stm.setInt(5, v.getCodigo());
            stm.executeUpdate();
            stm.close();
            con.close();
            JOptionPane.showMessageDialog(null, "Venda Finalizada com Sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Cadastrar o Venda!", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }
    public List<Venda> listarTodos(int codigo) {
        Connection con = Conectar.getConectar();
        List<Venda> prList = new ArrayList();
        String sql = "SELECT * FROM Venda, Caixa, Cliente WHERE Venda.codigo = ? and "
                + "Venda.idCaixa_FK = Caixa.idCaixa and "
                + "Venda.idCliente_FK = Cliente.idCliente";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, codigo);
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Venda v = new Venda();
                v.setIdVenda(resultados.getInt("Venda.idVenda"));
                v.setCodigo(resultados.getInt("Venda.codigo"));
                v.setValorTotalComDesconto(resultados.getFloat("Venda.valorTotalComDesconto"));
                v.setDesconto(resultados.getFloat("Venda.desconto"));
                
                Caixa c = new Caixa();
                c.setIdCaixa(resultados.getInt("Caixa.idCaixa"));
                c.setCodigo(resultados.getInt("Caixa.codigo"));
                v.setCaixa(c);
                
                Cliente cl = new Cliente();
                cl.setIdCliente(resultados.getInt("Cliente.idCliente"));
                cl.setNomeCompleto(resultados.getString("Cliente.nomeCompleto"));
                v.setCliente(cl);
                
                prList.add(v);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }
}
