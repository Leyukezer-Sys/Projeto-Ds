package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Venda;
import mapeamento.Produto;
import mapeamento.Venda_Produto;
import utilitario.Conectar;

public class VendaProdutoDao {

    public void inserir(Venda_Produto vp) {
        Connection con = Conectar.getConectar();
        String sql = "INSERT INTO Venda_Produto(quantidadeProduto,dataDaCompra,valorFinal,idVenda_FK,idProduto_FK) VALUES(?,?,?,?,?)";
        try (PreparedStatement stm = con.prepareStatement(sql)) {

            stm.setInt(1, vp.getQuantidadePorduto());
            stm.setString(2, vp.getDataDaCompra());
            stm.setFloat(3, vp.getValorFinal());
            stm.setInt(4, vp.getVenda().getIdVenda());
            stm.setInt(5, vp.getProduto().getIdProduto());
            stm.executeUpdate();
            stm.close();
            con.close();
            JOptionPane.showMessageDialog(null, "Venda Cadastrado com Sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Cadastrar o Venda De Produto!", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }

    public void atualizar(Venda_Produto vp) {
        Connection con = Conectar.getConectar();
        String sql = "UPDATE Venda_Produto SET quantidadeProduto= ?, dataDaCompra= ?, valorFinal= ?, idVenda_FK= ?, preco= ?, idProduto_FK= ? WHERE idVenda_Produto= ?";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, vp.getQuantidadePorduto());
            stm.setString(2, vp.getDataDaCompra());
            stm.setFloat(3, vp.getValorFinal());
            stm.setInt(4, vp.getVenda().getIdVenda());
            stm.setInt(5, vp.getProduto().getIdProduto());
            stm.executeUpdate();
            JOptionPane.showMessageDialog(null, "Venda Atualizado com Sucesso!");
            stm.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Atualizar Produto", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }

    }

    public void deletar(Venda_Produto vp) {
        Connection con = Conectar.getConectar();
        String sql = "DELETE FROM Venda_Produto WHERE idVenda_Produto= ?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir a venda?", "Exclusão", JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION) {
            try (PreparedStatement stm = con.prepareStatement(sql)) {
                stm.setInt(1, vp.getIdVenda_Produto());
                stm.executeUpdate();
                JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
                stm.close();
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Erro ao deletar", null, JOptionPane.ERROR_MESSAGE);
                System.out.println(e.getMessage());
            }
        }
    }

    public List<Venda_Produto> listarTodos(String nome) {
        Connection con = Conectar.getConectar();
        List<Venda_Produto> prList = new ArrayList();
        String sql = "SELECT * FROM Venda_Produto, Produto, Venda WHERE "
                + "Venda_Produto.idVenda_FK = Venda.idVenda and "
                + "Venda_Produto.idProduto_FK = Produto.idProduto and "
                + "nome Like ? ORDER BY Produto.nome";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setString(1, "%" + nome + "%");
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Venda_Produto vp = new Venda_Produto();
                vp.setIdVenda_Produto(resultados.getInt("Venda_Produto.idVenda_Produto"));
                vp.setQuantidadePorduto(resultados.getInt("Venda_Produto.quantidadeProduto"));
                vp.setValorFinal(resultados.getFloat("Venda_Produto.valorFinal"));

                Venda v = new Venda();
                v.setIdVenda(resultados.getInt("Venda.idVenda"));
                vp.setVenda(v);

                Produto p = new Produto();
                p.setIdProduto(resultados.getInt("Produto.idProduto"));
                vp.setProduto(p);

                prList.add(vp);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

    public List<Venda_Produto> listarTodos() {
        Connection con = Conectar.getConectar();
        List<Venda_Produto> prList = new ArrayList();
        String sql = "SELECT * FROM Venda_Produto, Produto, Venda WHERE "
                + "Venda_Produto.idVenda_FK = Venda.idVenda and "
                + "Venda_Produto.idProduto_FK = Produto.idProduto ";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Venda_Produto vp = new Venda_Produto();
                vp.setIdVenda_Produto(resultados.getInt("Venda_Produto.idVenda_Produto"));
                vp.setQuantidadePorduto(resultados.getInt("Venda_Produto.quantidadeProduto"));
                vp.setValorFinal(resultados.getFloat("Venda_Produto.valorFinal"));

                Venda v = new Venda();
                v.setIdVenda(resultados.getInt("Venda.idVenda"));
                vp.setVenda(v);

                Produto p = new Produto();
                p.setIdProduto(resultados.getInt("Produto.idProduto"));
                vp.setProduto(p);

                prList.add(vp);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

    public List<Venda_Produto> listarTodos(int id) {
        Connection con = Conectar.getConectar();
        List<Venda_Produto> prList = new ArrayList();
        String sql = "SELECT * FROM Produto, Fornecedor WHERE idProduto = ? and "
                + "Venda_Produto.idVenda_FK = Venda.idVenda and "
                + "Venda_Produto.idProduto_FK = Produto.idProduto";
        try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, id);
            ResultSet resultados = stm.executeQuery();
            while (resultados.next()) {
                Venda_Produto vp = new Venda_Produto();
                vp.setIdVenda_Produto(resultados.getInt("Venda_Produto.idVenda_Produto"));
                vp.setQuantidadePorduto(resultados.getInt("Venda_Produto.quantidadeProduto"));
                vp.setValorFinal(resultados.getFloat("Venda_Produto.valorFinal"));

                Venda v = new Venda();
                v.setIdVenda(resultados.getInt("Venda.idVenda"));
                vp.setVenda(v);

                Produto p = new Produto();
                p.setIdProduto(resultados.getInt("Produto.idProduto"));
                vp.setProduto(p);

                prList.add(vp);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar a Lista", null, JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
        return prList;
    }

}
