package mapeamento;

public class Caixa {

    private int idCaixa, codigo;
    private String periodoInicial, periodoFinal, horarioAbertura, horarioFechamento;
    private float metaEmpresa, valorTotalEntrada, valorTotalSaida;
    private Usuario usuario;

    public int getIdCaixa() {
        return idCaixa;
    }

    public void setIdCaixa(int idCaixa) {
        this.idCaixa = idCaixa;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getPeriodoInicial() {
        return periodoInicial;
    }

    public void setPeriodoInicial(String periodoInicial) {
        this.periodoInicial = periodoInicial;
    }

    public String getPeriodoFinal() {
        return periodoFinal;
    }

    public void setPeriodoFinal(String periodoFinal) {
        this.periodoFinal = periodoFinal;
    }

    public String getHorarioAbertura() {
        return horarioAbertura;
    }

    public void setHorarioAbertura(String horarioAbertura) {
        this.horarioAbertura = horarioAbertura;
    }

    public String getHorarioFechamento() {
        return horarioFechamento;
    }

    public void setHorarioFechamento(String horarioFechamento) {
        this.horarioFechamento = horarioFechamento;
    }

    public Float getMetaEmpresa() {
        return metaEmpresa;
    }

    public void setMetaEmpresa(Float metaEmpresa) {
        this.metaEmpresa = metaEmpresa;
    }

    public Float getValorTotalEntrada() {
        return valorTotalEntrada;
    }

    public void setValorTotalEntrada(Float valorTotalEntrada) {
        this.valorTotalEntrada = valorTotalEntrada;
    }

    public Float getValorTotalSaida() {
        return valorTotalSaida;
    }

    public void setValorTotalSaida(Float valorTotalSaida) {
        this.valorTotalSaida = valorTotalSaida;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

}
