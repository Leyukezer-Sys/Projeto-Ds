package mapeamento;

public class Despesa {
    private int idDispesa, quantidade;
    private String tipoDeRenda, dataVenda, dataEntrega;
    private float valorUnitario, porcentagem;
    private double valorFinal;
    private Fornecedor fornecedor;

    public int getIdDispesa() {
        return idDispesa;
    }

    public void setIdDispesa(int idDispesa) {
        this.idDispesa = idDispesa;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getTipoDeRenda() {
        return tipoDeRenda;
    }

    public void setTipoDeRenda(String tipoDeRenda) {
        this.tipoDeRenda = tipoDeRenda;
    }

    public String getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }

    public String getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(String dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public float getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(float valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public float getPorcentagem() {
        return porcentagem;
    }

    public void setPorcentagem(float porcentagem) {
        this.porcentagem = porcentagem;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }
    
    
}
