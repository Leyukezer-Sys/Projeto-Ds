package mapeamento;

import java.awt.image.BufferedImage;

public class Usuario {
    private int idUsuario;
    private String nome,sobrenome, cpf, telefone, email, userName, senha, dataDeLogin,horarioDeLogin,foto;
    private Funcionario funcionario;

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getDataDeLogin() {
        return dataDeLogin;
    }

    public void setDataDeLogin(String dataDeLogin) {
        this.dataDeLogin = dataDeLogin;
    }

    public String getHorarioDeLogin() {
        return horarioDeLogin;
    }

    public void setHorarioDeLogin(String horarioDeLogin) {
        this.horarioDeLogin = horarioDeLogin;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
    
}
