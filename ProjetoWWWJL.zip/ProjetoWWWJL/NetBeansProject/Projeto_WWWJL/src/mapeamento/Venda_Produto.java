package mapeamento;

public class Venda_Produto {
    private int idVenda_Produto, quantidadePorduto;
    private String dataDaCompra;
    private float valorFinal;
    private Venda venda;
    private Produto produto;

    public int getIdVenda_Produto() {
        return idVenda_Produto;
    }

    public void setIdVenda_Produto(int idVenda_Produto) {
        this.idVenda_Produto = idVenda_Produto;
    }

    public int getQuantidadePorduto() {
        return quantidadePorduto;
    }

    public void setQuantidadePorduto(int quantidadePorduto) {
        this.quantidadePorduto = quantidadePorduto;
    }

    public String getDataDaCompra() {
        return dataDaCompra;
    }

    public void setDataDaCompra(String dataDaCompra) {
        this.dataDaCompra = dataDaCompra;
    }

    public float getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(float valorFinal) {
        this.valorFinal = valorFinal;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }
    
    
}
